import React, { Component } from 'react';
import logo from './logo.svg';
import 'bulma/css/bulma.css';
import Heading from './components/Heading';
import Buttons from './components/Buttons';

class App extends Component {
	constructor() {
		super();

		this.state = {
			counter: 0,
		}

		this.handleDecrement = this.handleDecrement.bind(this);
		this.handleIncrement = this.handleIncrement.bind(this);
	}
	handleIncrement() {
		this.setState({ counter: this.state.counter + 1 })
	}
	handleDecrement() {
		this.setState({ counter: this.state.counter - 1 })
	}
	render() {
		const{counter}=this.state;
		return (
			<div className="section">
				<div className="container">

					<h1>
						this is the counter:{this.state.counter}
					</h1>
					{/* <button onClick={this.handleIncrement}>+</button>
					<button onClick={this.handleDecrement}>-</button> */}
					<Heading text={counter}/>
					<Buttons
						increment={this.handleIncrement}
						incrementText = '+'
						decrementText = '-'
						decrement={this.handleDecrement}
					/>
				</div>

			</div>
		);
	}
}

export default App;
