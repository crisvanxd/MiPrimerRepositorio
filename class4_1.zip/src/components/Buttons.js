import React from 'react'

const Buttons = ({ increment, decrement,incrementText,decrementText }) => (
	<div>
		<button onClick={increment}>{incrementText}</button>
		<button onClick={decrement}>{decrementText}</button>
	</div>
)
export default Buttons;