import { Component } from '@angular/core';

@Component({
	selector: "app-prueba",
	templateUrl: "./miprueba.component.html",
	styleUrls: ["./miprueba.component.css"]
})
export class PruebaComponent {
	nombreCurso: string = "FullStack xD";
	fechaHora = new Date();
	constructor() {
		setInterval(() => {
			this.fechaHora = new Date();
		}, 1000)
	}
};
