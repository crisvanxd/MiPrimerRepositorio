import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
	handleClick = (event) => {
		console.log(event.currentTarget);
		console.log(event.target);
		console.log(event.type);
		console.log(event instanceof MouseEvent);
		console.log(event.nativeEvent instanceof MouseEvent);
		event.preventDefault();
	}

	handle = (event) => {

		switch (event.type) {
			case ('mousedown'):
				console.log('mousedownxD');

				break;
			case ('click'):
				console.log('clickxD');
				break;
			case ('dblClick'):
				console.log('dblClickxD');
				break;
			default:
				break;
		}
		event.preventDefault();

	}
	inputFocus = (event) => {
		console.log(this.elem);
		//this.elem.focus();
		this.elem.style.display = 'none';
		event.preventDefault();
	}

	render() {
		return (
			<div className="App">
				<form onClick={this.handleClick}>
					<div>
						<button>
							Dale Click
						</button>
					</div>
				</form>
				<button onClick={this.handle}
					onDoubleClick={this.handle}
					onMouseDown={this.handle}>
					Dale Click
				</button>
				<form>
					<input type='text' ref={xelement => this.elem = xelement} />
					<button onClick={this.inputFocus}>Click</button>
				</form>

			</div>
		);
	}
}

export default App;
