import React,{Component} from 'react'
import PropTypes from 'prop-types'

//Puedes indicar propiedad por propiedad de lo que vas a recibir 
//O puedes colocar todo el props
//const UserItem = ({name,email,username,id,address})=>{
//pero se usaria dentro como props.name
//<strong>{props.name}</strong> 
const UserItem = ({name,email,username,id,address})=>{

	return(
		<div className="box">
		<article className="media">
			<div className="media-left">
			<figure className="image is-64x64">
				<img src="https://bulma.io/images/placeholders/128x128.png" alt="Image" />
			</figure>
			</div>
			<div className="media-content">
			<div className="content">
				<p>
				{id}
				<br />
				<strong>{name}</strong> <small>{email}</small> <small>{username}</small>
				<br /> 
				Ciudad : {address.city}
				</p>
			</div>
			<nav className="level is-mobile">
				<div className="level-left">
				<a className="level-item" aria-label="reply">
					<span className="icon is-small">
					<i className="fas fa-reply" aria-hidden="true"></i>
					</span>
				</a>
				<a className="level-item" aria-label="retweet">
					<span className="icon is-small">
					<i className="fas fa-retweet" aria-hidden="true"></i>
					</span>
				</a>
				<a className="level-item" aria-label="like">
					<span className="icon is-small">
					<i className="fas fa-heart" aria-hidden="true"></i>
					</span>
				</a>
				</div>
			</nav>
			</div>
		</article>
	</div>
	)
}

UserItem.propTypes = {
	name : PropTypes.string,
	email : PropTypes.string,
	username : PropTypes.string,
	address : PropTypes.shape(
		{
			street : PropTypes.string,
		}

	)
}

export default UserItem