import React ,{Component} from 'react'
import PropTypes from 'prop-types'
import UserItem from './UserItem'

/*
*Sirve para hacer el mapeo de los Usuarios y renderizar uno por uno
*/
class UserList extends Component{
render(){
	const {users} = this.props;
	return(
		<div>
			{
				users.map((user,i)=><UserItem key={i} {...user} />)
			}
		</div>
	)
	}
}
UserList.propTypes = {
	//users:PropTypes.string,
}


//Aca se define como publica lo que cree
//puedo crear mas clases pero solo estoy poniendo como ambito publico UserList
//Siempre se exporta por lo tanto el mismo nombre de la Clase
export default UserList