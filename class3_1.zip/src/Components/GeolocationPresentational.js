import React, { Component } from 'react';

const GeolocationPresentational = ({ latitude, longitude }) => (
	<div>
	  <div>Latitude: {latitude}</div>
	  <div>Longitude: {longitude}</div>
	</div>
  )
  
  GeolocationPresentational.propTypes = {
	latitude: React.PropTypes.number,
	longitude: React.PropTypes.number,
  }