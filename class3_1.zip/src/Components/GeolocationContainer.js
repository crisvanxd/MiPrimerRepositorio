import React, { Component } from 'react';
import  

export default class GeolocationContainer extends React.Component {
	constructor(props) {
	  super(props);
	  this.state = {
		lat: null,
		log: null,
	  };
	  this.getlocation = this.getlocation.bind(this);
	}
  
	componentDidMount() {
		navigator.geolocation.getCurrentPosition(this.getlocation);
	}
  
	getlocation({ coords }) {
	  this.setState({
		  lat: coords.latitud,
		  log: coords.longitud
	  })
	}
  
	render() {
	  return (
		<GeolocationPresentational {...this.state} />
	  );
	}
  }