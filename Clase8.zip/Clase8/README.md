# React quickstart
For basic React application