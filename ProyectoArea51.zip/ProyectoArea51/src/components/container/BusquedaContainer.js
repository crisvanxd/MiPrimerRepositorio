import React, {
    Component
} from 'react';
import Button from '../presentational/Button';
import Input from '../presentational/Input';
import TareasList from './TareasList'
class BusquedaContainer extends Component {
    state = {
        textoFiltro: '',
        tareas: [{
                id:1,
                nombreTarea: 'Tarea1',
                Estado: 1
            },
            {
                id:2,
                nombreTarea: 'Tarea2',
                Estado: 1
            },
            {
                id:3,
                nombreTarea: 'Tarea3',
                Estado: 2
            }
        ],
    };

    // componentDidMount() {
    //     const users = 'https://jsonplaceholder.typicode.com/users'
    //     fetch(users).then(response => response.json()).then(data => {
    //         this.setState({
    //             users: data,
    //         })
    //     }).catch(error => {
    //         console.log(error);
    //     });
    // }

    handleChange = ({
        target
    }) => {
        this.setState({
            [target.name]: target.value,
        })
    }

    // _handleUpdateAdmin() {
    //     this.setState({
    //         admin: {
    //             name: 'x',
    //             age: 'y'
    //         }
    //     });
    // }

    render() {
        return (
            <div>
            <Input name='textoFiltro' onChange={this.handleChange} placeholder='Ingrese tarea a buscar' value={this.state.textoFiltro} />
            <br />
            <TareasList tareas={this.state.tareas} filtro={this.state.textoFiltro}/>
            <Button name='btnAgregar' texto='Agregar' />         
            </div>
        )
    }
}

export default BusquedaContainer;