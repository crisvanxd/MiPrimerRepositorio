import React, {
    Component
} from 'react'

const TareasList = ({
    tareas,
    filtro
}) => {
    console.log(filtro);
    
    const tareasFiltradas = tareas.filter(m => (m.nombreTarea.indexOf(filtro) !== -1))


return (
    <ul>
        {
            tareasFiltradas.map(tarea => (
                <li key={tarea.id}>                    
                    <div>
                        <strong>{tarea.nombreTarea}</strong>
                    </div>
                </li>
            ))
        }
    </ul>
)
}
export default TareasList;