import React from 'React';
import Styles from './Button.css';

const Button = ({
    name,
    texto
}) => {
    return ( 
    <button className={Styles.button} name={name}>{texto}</button>
    )
}

export default Button;