import React from 'react';
import styles from './Input.css';

const Input = ({
    name,
    onChange,
    placeholder,
    value
}) => {
    return (        
        <input           
        className={styles.Input}
        name={name}
        onChange={onChange}
        placeholder={placeholder}
        type='text'
        value={value}
        />
    )
}


export default Input;