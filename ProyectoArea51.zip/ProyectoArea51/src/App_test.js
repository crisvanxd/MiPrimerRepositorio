import React, {
    Component
} from 'react';

import styles from './App.css'
class App extends Component {
    state = {
        filtro: ''
    };

    handleChange = ({
        target
    }) => {
        //console.log(target);
        //<input type="text" name="filtro" value="h">
        this.setState({
            [target.name]: target.value,
        })
    }

    // handleClick = (event) => {
    //     console.log(event);
    //console.log(event.target);
    //
    //<input type="text" name="filtro" value="">
    //filtro
    //console.log(event.target.name);
    // console.log(event.currentTarget);
    // console.log(event.target);
    // console.log(event.type);
    // console.log(event.target.value);
    // console.log(event instanceof MouseEvent);
    // console.log(event.nativeEvent instanceof MouseEvent);
    //     event.preventDefault()
    //   } 

    // handleSubmit = (e) => {
    //     e.preventDefault()
    //     console.log(`${this.state.firstName} ${this.state.lastName}`)
    //   }

    render() {
        return (
            <div>
            {/* <form onSubmit={this.handleSubmit}> */}
            <form>
            <input
            name='filtro'
            onChange={this.handleClick}
            type='text'            
            value={this.state.filtro}            
            ></input>
            <button>Submit</button>
            </form>
            </div>
        )
    }
}
export default App;