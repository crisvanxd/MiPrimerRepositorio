import React, {
    Component
} from 'react';

import styles from './App.css'
import BusquedaContainer from '../src/components/container/BusquedaContainer'

class App extends Component {
    render() {
        return ( 
        <div>         
         <BusquedaContainer />
        </div>
        )
    }
}
export default App;