import React, { Component } from 'react';
import './App.css';
import GistList from './component/GistList'

class App extends Component {
	constructor() {
		super();
		this.state = {
			infoGists: [],
			titulo: 'Mi primer Ejercicio'
		}
	}

	componentDidMount() {
		const infoGistsApi = "https://api.github.com/users/gaearon/gists";
		fetch(infoGistsApi).then(
			responde => responde.json()
		).then(
			infoGists => {
				this.setState({
					infoGists
				})
			}
			).catch(error => console.log(error))
		console.log(infoGistsApi);
	}

	render() {
		const { infoGists, titulo } = this.state;
		return (
			<div className="section">
				<div className="container">
					<h1>{titulo}</h1>
					{<GistList infoGists={infoGists} />}
				</div>
			</div>
		);
	}
}

export default App;
