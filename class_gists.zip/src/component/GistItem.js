import React from 'react'
import PropTypes from 'prop-types'

//Puedes indicar propiedad por propiedad de lo que vas a recibir 
//O puedes colocar todo el props
//const UserItem = ({name,email,username,id,address})=>{
//pero se usaria dentro como props.name
//<strong>{props.name}</strong> 
const GistItem = ({ url }) => {

	return (
		<div className="classGistItem">
			<p>
				{url}
				{/* <br />
				Ciudad : {address.city} */}
			</p>
		</div>
	)
}

GistItem.propTypes = {
	url: PropTypes.string,
	// address: PropTypes.shape(
	// 	{
	// 		street: PropTypes.string,
	// 	}

	// )
}

export default GistItem