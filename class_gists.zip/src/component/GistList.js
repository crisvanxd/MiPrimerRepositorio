import React, { Component } from 'react'
import PropTypes from 'prop-types'
import GistItem from './GistItem'


class GistList extends Component {
	render() {
		const { infoGists } = this.props;
		return (
			<div>
				{
					infoGists.map((infoGists, i) => <GistItem key={i} {...infoGists} />)
				}
			</div>
		)
	}
}
GistList.propTypes = {
	infoGists: PropTypes.array,
}


//Aca se define como publica lo que cree
//puedo crear mas clases pero solo estoy poniendo como ambito publico UserList
//Siempre se exporta por lo tanto el mismo nombre de la Clase
export default GistList