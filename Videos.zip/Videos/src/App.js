import React, { Component } from 'react'
import styles from './App.css'

// import ys from 'youtube-api-v3-search';
import VideoContainer from './components/containers/VideoContainer';
// import VideoList from './components/presentational/VideoList';
// import VideoContainer from './components/containers/VideoContainer';
// import VideoContainer from './components/containers/VideoContainer';


export default class App extends Component {

	// state = {
	// 	message: 'Message',
	// }

	// handleToggleMessage = (message) => {
	// 	this.setState({ message })
	// }

	render() {
		return (
			<div className={styles.app}>
			  {/* <div className={styles.container}>
				<h1>{this.state.message}</h1>
				<button 
				  className={styles.buttonSuccess} 
				  onClick={() => this.handleToggleMessage('Hello World!!! :D')}>Hello</button>
				<button 
				  className={styles.buttonPrimary} 
				  onClick={() => this.handleToggleMessage('Bye World!!! :(')}>Bye</button>
			  </div> */}
			  <div>
				  <VideoContainer />
			</div>
			</div>
		  )
	}
}