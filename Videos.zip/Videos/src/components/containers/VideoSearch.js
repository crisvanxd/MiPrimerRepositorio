import React, { Component } from 'react'

class VideosSearch extends Component {
	state = {
		term: ''
	}

	handleOnChange = (e) => {
		const { changeTerm } = this.props;
		const term = e.targe.value;
		this.setState({ term });
		changeTerm(term);
	}

	render() {
		return (
			<div>
				<h1>Video Search</h1>
				<input
					type="text"
					placeholder="Buscar video"
					value={this.state.term}
					onChange={this.handleOnChange} />
			</div>
		)
	}
}

export default VideosSearch;