import React, { Component } from 'react'

import ys from 'youtube-api-v3-search';
import VideoSearch from './VideoSearch';
import VideoList from '../presentational/VideoList'
import VideoDetail from '../presentational/VideoDetail'

const youtubeApi = 'AIzaSyCKYNlf7DK6Rs_L9U0HHQWTxEM4QYo-ofQ'
class VideoContainer extends Component {

	state = {
		videos: [],
		currentVideo: null,
		term: 'perritos'
	}

	componentDidMount() {

		const opts = {
			q: 'perritos',
			type: 'videos'
		};

		ys(youtubeApi, opts).then((data) => {
			this.setState({ videos: data.items })
		});
	}

	handleChangeTerm = (term) => {
		this.setState({ term })
	}

	render() {
		return (
			<div>
				<VideoSearch handleChangeTerm />
				<VideoDetail />
				<VideoList videos={this.state.videos} textSearch={term} />
			</div>
		)
	}
}
export default VideoContainer;