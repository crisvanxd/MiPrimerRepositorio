import React from 'React'

const VideoDetail = () => {
	
	return (
		<h1>VideoDetail</h1>
	  )
};

export default VideoDetail;