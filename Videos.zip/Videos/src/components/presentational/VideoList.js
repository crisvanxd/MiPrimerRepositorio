import React from 'react'

const VideoList = ({ videos, textSearch }) => {
	return (
		<div>
			{/* <h1>VideoList</h1> */}
			<ul>
				{
					videos.map(contact => (
						<li key={contact.id.videoId}>
							{/* <img src="https://i.ytimg.com/vi/EZpNQntnXck/mqdefault.jpg" role="presentation" /> */}
							<img src={contact.snippet.thumbnails.medium.url} role="presentation" />
							<div className="contactData">
								<strong>{contact.snippet.description}</strong>
							</div>
						</li>
					))
				}
			</ul>
		</div>
	)
};

export default VideoList;