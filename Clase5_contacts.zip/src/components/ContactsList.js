import React from 'react';
import loaderHOC from "../HoC/LoaderHOC"

const ContactList = ({
	contacts, filterText
}) => {
	console.log(contacts);
	
	const filteredContacts = contacts.filter(
		contact => (
			contact.name.indexOf(filterText) !== -1
		)
	)
	console.log(filteredContacts);
	
	return (
		<ul>
			{
				filteredContacts.map(
					contact =>
						(
							<li key={contact.email}>
								<img src={contact.thumbnail} role="presentation" />
								<div className="contactData">
								<strong>{contact.name}</strong><br /><email>{contact.email}</email>
								</div>
							</li>
						)
				)
			}
		</ul>
	)
}
export default loaderHOC('Contacts')(ContactList);