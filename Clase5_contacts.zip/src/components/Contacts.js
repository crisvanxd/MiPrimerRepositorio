import React, { Component } from 'react'
import SearchBar from './SearchBar'
import ContactsList from './ContactsList'

class Contacts extends Component {
	state = {
		filterText: ''
	}


	handledUserInput = (searchTerm) => {
		this.setState({
			filterText: searchTerm
		})
	}

	render() {
		return (
			<div className="contacts">
				<SearchBar
					filterText={this.state.filterText}
					onUserInput={this.handledUserInput}
				/>
				<ContactsList
					contacts={this.props.contacts}
					filterText={this.state.filterText}
				/>
			</div>
		)
	}
}


export default Contacts;