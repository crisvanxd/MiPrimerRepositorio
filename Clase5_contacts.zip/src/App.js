import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Contacts from './components/Contacts'

class App extends Component {
	state = {
		contacts: [],
	}
	
	componentDidMount() {
		const usersAPI = "https://randomuser.me/api/?results=50&nat=us";
		fetch(usersAPI)
		.then(
			responde => responde.json()
		).then(
			data => {
				console.log(data);
				const contacts = data.results.map(
					user=>(
						Object.assign(
							{},
							user,
							{
								name :`${user.name.first} ${user.name.last}`
								, email : `${user.email}`
							}
						)
					)
				)
				this.setState({
					contacts
				})
				console.log(this.state);
			}
			).catch(error => console.log(error))
	}


  render() {
    return (
      <div className="container">
        <Contacts contacts={this.state.contacts} />
      </div>
    );
  }
}

export default App;
